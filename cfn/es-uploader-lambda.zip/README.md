# Configuring Kibana

After the es-uploader-lambda has bootstrapped the lab by indexing a set of data from (s3|aurora) to elasticsearch, Kibana needs to be configured using the following steps:
1. Create an index pattern. Kibana uses index patterns to retrieve data from Elasticsearch indices for things like visualizations. Since we want to visualize our results on a Coordinate Map, we need an index pattern. To create one:
    * From the Kibana Dashboard, go to the `Management` tab and then choose `Index Patterns`
    * For Step 1 of 2: Define index pattern, specify `logstash*` as the index pattern and then click `Next Step`
    * For Step 2 of 2: Configure settings, select `@timestamp` from the drop down and then click `Create Index Pattern`
2. Enable the tile map. [Due to licensing restrictions, the default installation of Kibana on Amazon ES domains that use Elasticsearch 5.x or greater does not include a map server for tile map visualizations](https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/es-kibana.html#es-kibana-map-server). 
    * From the Kibana Dashboard, go to the `Management` tab and then choose `Advanced Settings`
    * Scroll down to the `visualization:tileMap:WMSdefaults` and click the `edit` button
    * Replace the json configuration object with the following json object and click 'Save`
    ```
    {
        "enabled": true,
        "options": {
            "format": "image/png",
            "transparent": true,
            "url": "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            "layers": "0"
        }
    }
    ```
    * Now Kibana has to be reloaded. To do this, close out of the Kibana web page and then re-open by navigating back to the Elasticsearch Domain console and clicking the Kibana link
3. Create a Coordinate Map visualization
    * From the Kibana Dashboard, go to the `Visualize` tab and then choose `Create a Visualization`
    * Choose `Coordinate Map` as the type
    * In the `From a New Search, Select Index` section, select the `logstash*` index pattern we created in step 1
    * Under the `Buckets ... Select buckets type` section click `Geo Coordinates`
    * Select `Geohash` for the Aggregation
    * Select `geo.coordinates` for the field
    * Change the `Time Range` by clicking the tool in the upper-right portion of the web page, and then from the `Quick` tab select `Last 5 years`
    * You should now see the coordinate map populated with geocoordinates on the map from the indexed data in elasticsearch

# CloudFormation

* The top-level template file url for CloudFormation to create the stack is `https://s3-us-west-2.amazonaws.com/reinvent2018-bootcamp/s3-elasticsearch-lambda-indexer.yaml`
* To sync the local CloudFormation templates into S3 from the root of the workspace: `aws s3 sync cfn s3://reinvent2018-bootcamp` 