import { Config } from 'aws-sdk'
import { Client } from 'elasticsearch'

import { ElasticsearchDataIndexer } from './es-data-indexer'
import { IDataProvider } from './data-provider'
import { S3DataProvider } from './s3-data-provider'

const esEndpoint = process.env.ES_ENDPOINT
const esRegion = process.env.AWS_REGION

const indexConfig = {
    name: process.env.ES_INDEX_NAME,
    type: process.env.ES_INDEX_TYPE,
    mappings: [
        {
            properties: {
                geo: {
                    properties: {
                        coordinates: {
                            type: "geo_point"
                        }
                    }
                }
            }
        }
    ]
}

const esOptions = {
    hosts: [esEndpoint],
    connectionClass: require('http-aws-es'), 
    awsConfig: new Config({ region: esRegion }), 
    httpOptions: {} 
}

const s3Data = {
    region: process.env.AWS_REGION,
    bucket: process.env.S3_BUCKET,
    key: process.env.S3_KEY
}

const es = new Client(esOptions)

const dataProvider: IDataProvider = new S3DataProvider(s3Data.region, s3Data.bucket, s3Data.key)
const dataIndexer: ElasticsearchDataIndexer = new ElasticsearchDataIndexer(indexConfig, es, dataProvider) 

exports.handler = async (event, context) => {
    try {
        //await dataIndexer.deleteIndex()
        await dataIndexer.createIndex()
        await dataIndexer.index()
    } catch (error) {
        console.log(JSON.stringify(error))
    }
}

