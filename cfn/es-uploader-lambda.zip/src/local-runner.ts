require('./index').handler(null, null)

